export default function ComoFuncionaPage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Como funciona</h1>
      <p>Esta seção explica o fluxo de uso da plataforma de forma fictícia.</p>
      <ol className="list-decimal ml-6 space-y-3 text-gray-700">
        <li>Crie sua conta preenchendo um breve formulário de cadastro.</li>
        <li>Selecione uma das raspadinhas disponíveis na página de raspadinhas.</li>
        <li>Ao comprar, raspe com o mouse ou dedo e descubra se ganhou (nesta demo tudo é fictício).</li>
        <li>Receba um prêmio fictício e continue explorando a navegação.</li>
      </ol>
    </div>
  )
}