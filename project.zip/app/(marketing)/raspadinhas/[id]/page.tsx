import { notFound } from 'next/navigation'

const cards = [
  { id: '1', name: 'Sorte Fictícia', price: 10, maxPrize: 1000, category: 'Dinheiro', description: 'Uma raspadinha de exemplo para fins de demonstração.' },
  { id: '2', name: 'Tesouro Oculto', price: 15, maxPrize: 5000, category: 'Produtos', description: 'Raspadinha com prêmios de produtos fictícios.' },
  { id: '3', name: 'Riqueza Virtual', price: 20, maxPrize: 2000, category: 'Dinheiro', description: 'Outra raspadinha de demonstração.' }
]

export default function ScratchDetailPage({ params }: { params: { id: string } }) {
  const card = cards.find((c) => c.id === params.id)
  if (!card) return notFound()
  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <h1 className="text-3xl font-bold">{card.name}</h1>
      <p className="text-gray-600">Categoria: {card.category}</p>
      <p className="text-gray-600">Preço: R$ {card.price.toFixed(2)}</p>
      <p className="text-gray-600">Prêmio máximo: R$ {card.maxPrize.toFixed(2)}</p>
      <p className="text-gray-700">{card.description}</p>
      <button className="bg-accent text-white py-2 px-4 rounded hover:bg-accent/90" onClick={() => alert('Compra de demonstração!')}>Comprar (demo)</button>
    </div>
  )
}