import Link from 'next/link'

interface ScratchCard {
  id: string
  name: string
  price: number
  maxPrize: number
  category: string
}

const cards: ScratchCard[] = [
  { id: '1', name: 'Sorte Fictícia', price: 10, maxPrize: 1000, category: 'Dinheiro' },
  { id: '2', name: 'Tesouro Oculto', price: 15, maxPrize: 5000, category: 'Produtos' },
  { id: '3', name: 'Riqueza Virtual', price: 20, maxPrize: 2000, category: 'Dinheiro' }
]

export default function RaspadinhasPage() {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Raspadinhas</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((card) => (
          <div key={card.id} className="border p-4 rounded-lg bg-white shadow flex flex-col justify-between">
            <div>
              <h2 className="text-xl font-semibold mb-1">{card.name}</h2>
              <p className="text-sm text-gray-500 mb-2">Categoria: {card.category}</p>
              <p className="text-sm text-gray-500">Preço: R$ {card.price.toFixed(2)}</p>
              <p className="text-sm text-gray-500">Prêmio máx.: R$ {card.maxPrize.toFixed(2)}</p>
            </div>
            <Link href={`/raspadinhas/${card.id}`} className="mt-4 inline-block text-center bg-secondary text-white py-2 px-4 rounded hover:bg-secondary/90">
              Detalhes
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}