export default function DepoimentosPage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Depoimentos</h1>
      <p className="text-gray-700">Veja alguns comentários fictícios de pessoas que experimentaram a plataforma demo.</p>
      <div className="space-y-4">
        <blockquote className="border-l-4 border-primary pl-4 italic text-gray-700">
          "Achei a navegação simples e intuitiva, mal posso esperar pela versão real!"
          <cite className="block mt-2 text-sm text-gray-500">– Usuário A</cite>
        </blockquote>
        <blockquote className="border-l-4 border-secondary pl-4 italic text-gray-700">
          "As raspadinhas de demonstração foram divertidas para entender o fluxo."
          <cite className="block mt-2 text-sm text-gray-500">– Usuário B</cite>
        </blockquote>
      </div>
    </div>
  )
}