"use client"
import { useState } from 'react'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Login de demonstração: ' + email)
  }
  return (
    <div className="max-w-sm mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-center">Entrar</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">E‑mail</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Senha</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full border p-2 rounded" />
        </div>
        <button type="submit" className="w-full bg-primary text-white py-2 rounded hover:bg-primary/90">Entrar</button>
      </form>
      <p className="text-center text-sm">Não tem conta? <a href="/register" className="text-primary hover:underline">Registre‑se</a></p>
    </div>
  )
}