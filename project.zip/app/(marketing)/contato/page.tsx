"use client"
import { useState } from 'react'

export default function ContatoPage() {
  const [message, setMessage] = useState('')
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Mensagem enviada: ' + message)
  }
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Contato</h1>
      <p className="text-gray-700">Envie uma mensagem de demonstração.</p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={4} className="w-full border p-2 rounded" placeholder="Escreva sua mensagem" />
        <button type="submit" className="bg-primary text-white py-2 px-4 rounded hover:bg-primary/90">Enviar</button>
      </form>
    </div>
  )
}