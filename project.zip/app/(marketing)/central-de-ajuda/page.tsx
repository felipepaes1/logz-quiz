export default function CentralDeAjuda() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Central de Ajuda</h1>
      <p className="text-gray-700">Esta página contém perguntas e respostas fictícias para a versão de demonstração.</p>
      <ul className="list-disc ml-6 space-y-2 text-gray-700">
        <li>Como posso jogar uma raspadinha? – Acesse a página de raspadinhas e escolha uma.</li>
        <li>Preciso pagar para usar a demo? – Não, tudo é fictício.</li>
      </ul>
    </div>
  )
}