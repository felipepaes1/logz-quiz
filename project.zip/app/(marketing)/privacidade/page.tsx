export default function PrivacidadePage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Política de Privacidade</h1>
      <p className="text-gray-700">Nesta demonstração não coletamos dados reais.  Esta página é apenas ilustrativa.</p>
    </div>
  )
}