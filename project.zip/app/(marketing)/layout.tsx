// src/app/layout.tsx
import "../globals.css";

export const metadata = {
  title: "raspafy.demo",
  description: "Raspadinhas online com prêmios reais",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className="min-h-screen bg-background text-foreground antialiased">
        {children}
      </body>
    </html>
  );
}
