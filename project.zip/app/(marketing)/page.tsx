// app/page.tsx
"use client";

import Link from "next/link";
import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Gift, MousePointer2, Ticket, UserPlus, Wallet, Zap } from "lucide-react";

type Category = "all" | "money" | "products";

type Game = {
  id: string;
  title: string;
  description: string;
  price: number;
  category: Category;
  badge?: string;
  icon?: React.ReactNode;
};

const GAMES: Game[] = [
  {
    id: "centavo-da-sorte",
    title: "Centavo da Sorte",
    description: "Reúna 3 imagens iguais e conquiste prêmios.",
    price: 0.5,
    category: "money",
    icon: <Zap className="h-5 w-5" />,
  },
  {
    id: "raspadinha-suprema",
    title: "Raspadinha Suprema",
    description: "Reúna 3 imagens iguais e conquiste prêmios.",
    price: 3,
    category: "money",
    icon: <Ticket className="h-5 w-5" />,
  },
  {
    id: "raspa-relampago",
    title: "Raspa Relâmpago",
    description: "O valor correspondente será creditado na hora.",
    price: 3,
    category: "money",
    icon: <MousePointer2 className="h-5 w-5" />,
  },
  {
    id: "raspadinha-magica",
    title: "Raspadinha Mágica",
    description: "Reúna 3 imagens iguais e conquiste prêmios.",
    price: 5,
    category: "products",
    icon: <Gift className="h-5 w-5" />,
  },
];

const WINNERS: { name: string; prizeLabel: string; amount?: string }[] = [
  { name: "Letícia***", prizeLabel: "100 Reais", amount: "R$ 100,00" },
  { name: "Isabella***", prizeLabel: "Air Fryer", amount: "R$ 850,00" },
  { name: "Vanessa***", prizeLabel: "100 Reais", amount: "R$ 100,00" },
  { name: "Pedro***", prizeLabel: "Apple Watch", amount: "R$ 3.200,00" },
  { name: "Rodrigo***", prizeLabel: "Apple Watch", amount: "R$ 3.200,00" },
  { name: "Ricardo***", prizeLabel: "Shopee Gift Card", amount: "R$ 500,00" },
];

export default function Home() {
  const counts = useMemo(() => {
    const money = GAMES.filter((g) => g.category === "money").length;
    const products = GAMES.filter((g) => g.category === "products").length;
    return { all: GAMES.length, money, products };
  }, []);

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top_right,theme(colors.slate.50),transparent_40%),linear-gradient(to_bottom,white,theme(colors.slate.50))]">
      <SiteHeader />

      {/* Hero */}
      <section className="relative">
        <div className="container mx-auto max-w-6xl px-4 py-12 md:py-16">
          <div className="grid items-center gap-8 md:grid-cols-2">
            <div className="space-y-6">
              <Badge variant="secondary" className="rounded-full px-3 py-1">
                +18 • Jogue com responsabilidade
              </Badge>

              <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl">
                Raspadinhas online com{" "}
                <span className="bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent">
                  prêmios reais
                </span>
              </h1>

              <p className="text-lg text-muted-foreground">
                A forma mais divertida de testar a sorte e ganhar dinheiro ou produtos. Plataforma segura, rápida e feita no Brasil.
              </p>

              <div className="flex flex-wrap gap-3">
                <Button size="lg" className="gap-2">
                  Registrar <ArrowRight className="h-4 w-4" />
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="#como-funciona">Como funciona</Link>
                </Button>
              </div>

              <div className="flex gap-6 pt-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                  PIX imediato
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2.5 w-2.5 rounded-full bg-sky-500" />
                  SSL seguro
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2.5 w-2.5 rounded-full bg-amber-500" />
                  Plataforma regulamentada
                </div>
              </div>
            </div>

            {/* Visual placeholder */}
            <div className="relative">
              <div className="aspect-[4/3] w-full rounded-2xl border bg-gradient-to-br from-slate-100 to-slate-200 shadow-sm" />
              <div className="absolute -bottom-6 left-6 right-6">
                <Card className="shadow-lg">
                  <CardContent className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-3">
                      <div className="rounded-xl bg-emerald-100 p-2 text-emerald-600">
                        <Wallet className="h-5 w-5" />
                      </div>
                      <div className="text-sm">
                        <div className="font-semibold">Saques instantâneos</div>
                        <div className="text-muted-foreground">Receba via PIX na hora</div>
                      </div>
                    </div>
                    <Badge className="rounded-full">Confiança Brasil</Badge>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
        <Separator />
      </section>

      {/* Tabs & Games */}
      <section className="container mx-auto max-w-6xl px-4 py-10 md:py-14">
        <div className="mb-6 flex items-center justify-between gap-4">
          <h2 className="text-2xl font-bold tracking-tight">Raspadinhas</h2>
          <div className="text-sm text-muted-foreground">
            {counts.all} jogos • {counts.money} dinheiro • {counts.products} produtos
          </div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3 md:w-auto">
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="money">Dinheiro</TabsTrigger>
            <TabsTrigger value="products">Produtos</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            <GameGrid games={GAMES} />
          </TabsContent>

          <TabsContent value="money" className="mt-6">
            <GameGrid games={GAMES.filter((g) => g.category === "money")} />
          </TabsContent>

          <TabsContent value="products" className="mt-6">
            <GameGrid games={GAMES.filter((g) => g.category === "products")} />
          </TabsContent>
        </Tabs>
      </section>

      {/* How it works */}
      <section id="como-funciona" className="bg-white/60 py-12 md:py-16">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Siga 4 passos simples</h2>
              <p className="text-muted-foreground">Comece a jogar e receber seus prêmios agora mesmo.</p>
            </div>
            <Button variant="outline" asChild>
              <Link href="#">Criar conta</Link>
            </Button>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <StepCard
              icon={<UserPlus className="h-5 w-5" />}
              title="Crie sua conta"
              description="Cadastre-se rapidamente e faça seu primeiro depósito."
            />
            <StepCard
              icon={<Ticket className="h-5 w-5" />}
              title="Selecione uma raspadinha"
              description="Escolha entre diversas opções com prêmios incríveis."
            />
            <StepCard
              icon={<MousePointer2 className="h-5 w-5" />}
              title="Raspe e descubra"
              description="Use o dedo ou mouse e veja se ganhou."
            />
            <StepCard
              icon={<Wallet className="h-5 w-5" />}
              title="Receba seu prêmio"
              description="Receba via PIX na hora ou retire produtos."
            />
          </div>
        </div>
      </section>

      {/* Winners */}
      <section className="container mx-auto max-w-6xl px-4 py-12 md:py-16">
        <div className="mb-6">
          <h2 className="text-2xl font-bold tracking-tight">Ganhadores recentes</h2>
          <p className="text-muted-foreground">Transparência e prêmios reais para todo o Brasil.</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {WINNERS.map((w, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-base font-semibold">{w.name}</CardTitle>
                <Badge variant="secondary">{w.prizeLabel}</Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold tabular-nums">{w.amount}</div>
                <p className="mt-1 text-sm text-muted-foreground">PIX confirmado</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="rounded-lg bg-emerald-500/10 p-2">
            <Gift className="h-5 w-5 text-emerald-600" />
          </div>
          <span className="text-lg font-bold">
            <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">raspafy</span>
            <span className="text-muted-foreground">.demo</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-6 md:flex">
          <Link href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Raspadinhas
          </Link>
          <Link href="#como-funciona" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Como funciona
          </Link>
          <Link href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Indique &amp; Ganhe
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Button variant="ghost" asChild>
            <Link href="#">Login</Link>
          </Button>
          <Button asChild>
            <Link href="#">Registrar</Link>
          </Button>
        </div>
      </div>
      <Separator />
    </header>
  );
}

function GameGrid({ games }: { games: Game[] }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {games.map((game) => (
        <Card key={game.id} className="group overflow-hidden">
          <CardHeader className="flex flex-row items-start gap-3">
            <div className="rounded-md bg-slate-100 p-2 text-slate-600">{game.icon ?? <Ticket className="h-5 w-5" />}</div>
            <div className="space-y-1">
              <CardTitle className="text-base">{game.title}</CardTitle>
              <CardDescription className="line-clamp-2">{game.description}</CardDescription>
              <div className="flex items-center gap-2 pt-1">
                <Badge variant="outline" className="rounded-full">
                  {game.category === "money" ? "Dinheiro" : "Produtos"}
                </Badge>
                {game.badge && <Badge className="rounded-full">{game.badge}</Badge>}
              </div>
            </div>
          </CardHeader>

          <CardContent className="px-0">
            <div className="mx-4 h-36 rounded-xl border bg-gradient-to-br from-slate-50 to-slate-100 transition-all duration-300 group-hover:shadow-md" />
          </CardContent>

          <CardFooter className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              A partir de{" "}
              <span className="font-semibold text-foreground">
                {game.price.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
              </span>
            </div>
            <Button size="sm" className="gap-1">
              Jogar <ArrowRight className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}

function StepCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center gap-3 space-y-0">
        <div className="rounded-lg bg-emerald-500/10 p-2 text-emerald-600">{icon ?? <Zap className="h-5 w-5" />}</div>
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">{description}</CardContent>
    </Card>
  );
}

function SiteFooter() {
  return (
    <footer className="border-t bg-white">
      <div className="container mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="mb-3 text-lg font-semibold">Links rápidos</div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="#" className="hover:text-foreground">Como funciona</Link></li>
              <li><Link href="#" className="hover:text-foreground">Raspadinhas</Link></li>
              <li><Link href="#" className="hover:text-foreground">Depoimentos</Link></li>
              <li><Link href="#" className="hover:text-foreground">Suporte</Link></li>
            </ul>
          </div>
          <div>
            <div className="mb-3 text-lg font-semibold">Central</div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="#" className="hover:text-foreground">Central de Ajuda</Link></li>
              <li><Link href="#" className="hover:text-foreground">Contato</Link></li>
              <li><Link href="#" className="hover:text-foreground">Termos de Uso</Link></li>
              <li><Link href="#" className="hover:text-foreground">Privacidade</Link></li>
            </ul>
          </div>
          <div>
            <div className="mb-3 text-lg font-semibold">Segurança</div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>SSL Seguro</li>
              <li>Plataforma Regulamentada</li>
              <li>Pagamento Seguro</li>
            </ul>
          </div>
          <div className="text-sm text-muted-foreground">
            <div className="mb-2 font-semibold text-foreground">Sobre</div>
            <p>Feito com ❤ por brasileiros.</p>
            <p className="mt-2">© 2025 raspafy.demo — Todos os direitos reservados.</p>
            <p className="mt-2">Jogue com responsabilidade • +18 anos • CNPJ fictício</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
