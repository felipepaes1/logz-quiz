export default function IndiqueEGanhePage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Indique & Ganhe</h1>
      <p className="text-gray-700">Esta página explica o programa de afiliados de forma fictícia. Aqui você poderia gerar um link de indicação e visualizar estatísticas.</p>
      <p className="text-gray-600">Como é uma demonstração, os dados mostrados são fictícios.</p>
    </div>
  )
}