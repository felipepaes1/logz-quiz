export default function TermosPage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Termos de Uso</h1>
      <p className="text-gray-700">Este texto é fictício e serve apenas para demonstração do layout.</p>
    </div>
  )
}